package jp.ne.so_net.ga2.no_ji.jcom.excel8;
/*
���[�N�V�[�g�̃^�C�v
ExcelWorksheets.Add()�Ŏg�p
*/

class XlSheetType {
	static final int xlWorksheet            = -4167;		// ����l
	static final int xlExcel4MacroSheet     = 3;
	static final int xlExcel4IntlMacroSheet = 4;
	static final int xlChart                = -4109;
	static final int xlDialogSheet          = -4116;
}
