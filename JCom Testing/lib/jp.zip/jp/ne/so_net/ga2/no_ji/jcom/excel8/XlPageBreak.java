package jp.ne.so_net.ga2.no_ji.jcom.excel8;
/*
���y�[�W�̎w����@
Range.PageBreak�Ŏg�p
*/

class XlPageBreak {
	static final int xlPageBreakAutomatic = -4105;
	static final int xlPageBreakManual    = -4135;
//	static final int xlPageBreakNone      = 
}
 